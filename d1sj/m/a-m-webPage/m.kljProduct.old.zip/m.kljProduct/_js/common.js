$(function () {
    $('.menu_btn').on('click', function () {
        $('.accordion').toggle();
    })
})
function scrollTop(imgUrl) {
    $('.scroll_top').remove()
    $(window).scroll(function () {
        var scroll = $(window).scrollTop()
        if (scroll > 200) {
            $('.scroll_top').remove()
            var newHtml = '<section class="scroll_top"><img src="' + imgUrl + '" /></section>'
            $('body').append(newHtml)
        } else {
            $('.scroll_top').remove()
        }
        $('.scroll_top').on('touchend', function () {
            $('body,html').animate({ scrollTop: 0 }, 500);
        })
    })
}